package com.example.myapplication.ViewModel

class MealDetiailsViewModel {
}